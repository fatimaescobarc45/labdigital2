#include <Arduino.h>
#include <stdint.h>

const int8_t led0 = 4;
const int8_t led1 = 17;
const int8_t led2 = 18;
const int8_t led3 = 21; 
const int8_t bsuma = 26;
const int8_t bresta = 25;
const int8_t bmodo = 33;

int8_t leds[4] = {led0, led1, led2, led3};

const int8_t ledBinario = 23;
const int8_t ledDecadas = 22;
int8_t modo = 0;  // 0 para binario, 1 para decadas
int8_t counter = 0;



// put function declarations here:
void contBinario();
void contDecadas();
int8_t cambiarModo();

// variables antirrebote
unsigned long ultimaSuma = 0;
unsigned long ultimaResta = 0;
unsigned long ultimoCambio = 0;
const unsigned long debounceDelay = 50; // ms


void setup() {
  // put your setup code here, to run once:
  pinMode(led0, OUTPUT);
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(led3, OUTPUT);
  pinMode(bsuma, INPUT_PULLUP);
  pinMode(bresta, INPUT_PULLUP);
  pinMode(bmodo, INPUT);
  pinMode(ledBinario, OUTPUT);
  pinMode(ledDecadas, OUTPUT);

}

void loop() {
  // put your main code here, to run repeatedly:
  static bool exModo = HIGH;
  bool lecturaModo = digitalRead(bmodo);

  if (exModo == HIGH && lecturaModo == LOW && (millis() - ultimoCambio) > debounceDelay) {
    modo++;
    ultimoCambio = millis();
  }
  exModo = lecturaModo;

    if(modo>1){
      modo = 0;
    }
    if(modo == 1){
      contBinario();
    }
    else{
      contDecadas();
    }


  }
  

  
  



// put function definitions here:


void contBinario() {
  digitalWrite(ledBinario, HIGH);
  digitalWrite(ledDecadas, LOW);

  static bool yaSumo = HIGH;
  static bool yaResto = HIGH;

  bool sumando = digitalRead(bsuma);
  bool restando = digitalRead(bresta);

  if (yaSumo == HIGH && sumando == LOW && (millis() - ultimaSuma) > debounceDelay) {
  counter++;
  ultimaSuma = millis();
}
yaSumo = sumando;

if (yaResto == HIGH && restando == LOW && (millis() - ultimaResta) > debounceDelay) {
  counter--;
  ultimaResta = millis();
}
yaResto = restando;

  if (counter > 15) {
    counter = 0;
  } else if (counter < 0) {
    counter = 15;
  }
  
  switch (counter) {
  case 0:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    break;
  case 1:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    break;
  case 2:
    digitalWrite(led0, LOW);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    break;
  case 3:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    break;
  case 4:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, LOW);
    break;
  case 5:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, LOW);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, LOW);
    break;
  case 6:
    digitalWrite(led0, LOW);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, LOW);
    break;
  case 7:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, LOW);
    break;
  case 8:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, HIGH);
    break;
  case 9:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, HIGH);
    break;
  case 10:
    digitalWrite(led0, LOW);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, LOW);
    digitalWrite(led3, HIGH);
    break;
  case 11:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, LOW);
    digitalWrite(led3, HIGH);
    break;
  case 12:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, HIGH);
    break;
  case 13:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, LOW);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, HIGH);
    break;
  case 14:
    digitalWrite(led0, LOW);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, HIGH);
    break;
  case 15:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, HIGH);
    break;
  default:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    break;
}  
  delay(50);
}

void contDecadas(){
  digitalWrite(ledBinario, LOW);
  digitalWrite(ledDecadas, HIGH);

  bool sumando = digitalRead(bsuma);
  bool restando = digitalRead(bresta);

  static bool yaSumo = HIGH;
  static bool yaResto = HIGH;

  if (yaSumo == HIGH && sumando == LOW && (millis() - ultimaSuma) > debounceDelay) {
  counter++;
  ultimaSuma = millis();
}
yaSumo = sumando;

if (yaResto == HIGH && restando == LOW && (millis() - ultimaResta) > debounceDelay) {
  counter--;
  ultimaResta = millis();
}
yaResto = restando;

  if(counter>4){
    counter = 0;
  }
  else if (counter<0){
    counter = 4;
  }
  

  switch(counter){
  case 0:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    delay(50);
    break;
  case 1:
    digitalWrite(led0, HIGH);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);    
    delay(50);

    break;
  case 2:
    digitalWrite(led0, LOW);
    digitalWrite(led1, HIGH);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    delay(50);
    break;
  case 3:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, HIGH);
    digitalWrite(led3, LOW);
    delay(50);
    break;
  case 4:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, HIGH);
    delay(50);
    break;
  default:
    digitalWrite(led0, LOW);
    digitalWrite(led1, LOW);
    digitalWrite(led2, LOW);
    digitalWrite(led3, LOW);
    delay(50);
    break;
}
}


